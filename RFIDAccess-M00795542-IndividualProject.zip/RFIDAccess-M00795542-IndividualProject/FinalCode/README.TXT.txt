The Python file needs to be run after the Arduino is programmed and giving output,
so first run the ArduinoCode.ino then run the Python.py code.
Hello.txt is the document in which data gets recorded into.